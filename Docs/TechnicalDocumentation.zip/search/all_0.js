var searchData=
[
  ['adduser',['AddUser',['../class_projet_banque_1_1_database_management.html#acf89f88775d4c333e5b17f76a4913530',1,'ProjetBanque.DatabaseManagement.AddUser(string email, string password, string type)'],['../class_projet_banque_1_1_database_management.html#a8897afb1154de9e27b3823465a9af0eb',1,'ProjetBanque.DatabaseManagement.AddUser(string email, string password, string type, double money)']]]
];
