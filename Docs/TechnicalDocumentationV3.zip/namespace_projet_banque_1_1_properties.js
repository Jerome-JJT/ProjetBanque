var namespace_projet_banque_1_1_properties =
[
    [ "Resources", "class_projet_banque_1_1_properties_1_1_resources.html", null ],
    [ "Settings", "class_projet_banque_1_1_properties_1_1_settings.html", null ]
];