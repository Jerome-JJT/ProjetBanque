var class_projet_banque_1_1_admin_users_list =
[
    [ "AdminUsersList", "class_projet_banque_1_1_admin_users_list.html#a91fe6ff510354c57d01bedc8f7b9b22c", null ],
    [ "Owner", "class_projet_banque_1_1_admin_users_list.html#a7e3c434e0b4a1e299d34bee42c8e3b1f", null ]
];