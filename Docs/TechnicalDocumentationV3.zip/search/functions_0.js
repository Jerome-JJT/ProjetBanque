var searchData=
[
  ['adduser',['AddUser',['../class_projet_banque_1_1_database_management.html#acf89f88775d4c333e5b17f76a4913530',1,'ProjetBanque.DatabaseManagement.AddUser(string email, string password, string type)'],['../class_projet_banque_1_1_database_management.html#a8897afb1154de9e27b3823465a9af0eb',1,'ProjetBanque.DatabaseManagement.AddUser(string email, string password, string type, double money)']]],
  ['adduserlist',['AddUserList',['../class_projet_banque_1_1_database_management.html#ae74398d6164b328937cb35bbbb5c038f',1,'ProjetBanque::DatabaseManagement']]],
  ['adminuser',['AdminUser',['../class_projet_banque_1_1_admin_user.html#a1ab74cd3e86e062f55b3d860eb9c6356',1,'ProjetBanque::AdminUser']]],
  ['adminuserslist',['AdminUsersList',['../class_projet_banque_1_1_admin_users_list.html#a91fe6ff510354c57d01bedc8f7b9b22c',1,'ProjetBanque::AdminUsersList']]]
];
