var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvw",
  1: "abcdefjlprstuw",
  2: "p",
  3: "abcdefghijoptuv",
  4: "eimt",
  5: "a",
  6: "aep",
  7: "adehilmnorstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties"
};

