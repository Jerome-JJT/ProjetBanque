var class_projet_banque_1_1_transaction =
[
    [ "Transaction", "class_projet_banque_1_1_transaction.html#a8e5d39a1547162d6dcdf59aa5a65a2bf", null ],
    [ "Amount", "class_projet_banque_1_1_transaction.html#aedd9199945b63b53613df8b6ddd2dc7f", null ],
    [ "Date", "class_projet_banque_1_1_transaction.html#ac76605aef978ac57cea8d373b617c7c0", null ],
    [ "Reason", "class_projet_banque_1_1_transaction.html#ac8625e281f75ad2eb1512db70cd90ec8", null ],
    [ "ReceiverDefine", "class_projet_banque_1_1_transaction.html#a868dda33ec8d27091ba8f68a64464e29", null ],
    [ "ReceiverIban", "class_projet_banque_1_1_transaction.html#aae1fe1c44f9b294bf92f549930a9218b", null ],
    [ "SenderDefine", "class_projet_banque_1_1_transaction.html#a03b93454caad64a6f271df40a88bb585", null ],
    [ "SenderIban", "class_projet_banque_1_1_transaction.html#a227080527c4fc0cd4cb37f15cf5f505e", null ]
];